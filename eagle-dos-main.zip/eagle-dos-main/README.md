# eagle-dos
# Author - white eagle

# This is only for educational purpose and so, it is a simple implementation of dos/ddos attack script.

The script is a basic implementation of a UDP flood attack, which is a type of denial-of-service (DoS) attack.


This is a  tool used for ddos attack from port 1 to port 65534.
You can attack to any network or to an android phone,a computer,a router or a website with their ip address and any port


commands
_______________
	$ apt update -y && apt upgrade -y
	$ pkg install git
	$ pkg install python2
	$ git clone https://github.com/WH1T3-E4GL3/eagle-dos.git
	$ cd eagle-dos.py
	$ git pull
	$ python eagle-dos.py
 


Tool used for dos attack.
Tool devoloped by white eagle.

Github   : https://github.com/WH1T3-E4GL3
Telegram : https://t.me/Ka_KsHi_HaTaKe
	

	
